<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div id="js-envato-elements-react"></div>

<script>
  jQuery( function () {
    window.ElementsReact && 'undefined' !== typeof envato_elements_react && window.ElementsReact.adminPageLoaded( envato_elements_react );
  } );
</script>
